All files are released under Creative Commons Attribution:
http://creativecommons.org/licenses/by/3.0/